<?php
class Admin extends BackendController
{
    public function index()
    {
        $data['products'] = $this->products->product_list();
        $this->load->view('admin/product_list',$data);
    }
    public function insert_products()
    {
        $config = [
            'upload_path' => './uploads/',
            'allowed_types' => 'jpg|png|jpeg',
            //'file_name' => isset($this->session->userdata('user_name'))?$this->session->userdata('user_name'):'image'
        ];
        $this->load->library('upload',$config);
        $this->upload->initialize($config);

        $this->form_validation->set_rules('product_name','Product Name','required');
        $this->form_validation->set_rules('product_qty','Product Quantity','required|numeric');
        $this->form_validation->set_rules('product_price','Product Price','required|numeric');
        $this->form_validation->set_rules('product_image','Product image','required');

        if($this->form_validation->run('product_form') == false  && $this->upload->do_upload('product_image') == false)
        {
            $upload_error = $this->upload->display_errors();
            $this->load->view('admin/product_form',compact('upload_error'));
        }
        else
        {
            $product_name   =   $this->input->post('product_name'); 
            $quantity       =   $this->input->post('quantity');
            $price          =   $this->input->post('price');
            $data = $this->upload->data();
            $image_path = base_url('uploads/'.$data['raw_name'].$data['file_ext']);
            $this->products->insert_products($product_name,$quantity,$price,$image_path);
            $this->load->view('admin/product_list');
        }
    }   
    public function product_form()
    {
        $this->load->view('admin/product_form');
    } 
}