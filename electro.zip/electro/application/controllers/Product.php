<?php

class Product extends FrontendController    {
    public function index()
    {
        $data['title'] = "Ecommerce - eMall";

        $this->load->view('templates/header',$data);
        $this->load->view('templates/navigation');
        $this->load->view('homepage',$data);
        $this->load->view('templates/footer');
    }
    
}