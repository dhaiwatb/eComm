<?php
class Products extends CI_Model{
    public function product_list()
    {
        $q = $this->db->get('products');

        if($q->num_rows())  
        {
            return $q->result_array();
        }
        else
        {
            return false;
        }
    }
    public function insert_products($name,$qty,$price)
    {
        $product = array(
            'product_name'  =>  $name,
            'quantity'      =>  $qty,
            'price'         =>  $price
        );

        $q = $this->db->insert('products',$product);
    }
}