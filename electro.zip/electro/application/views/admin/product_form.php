<?php include('header.php') ?>
<div class="row">
    <div class="col-lg-12 col-sm">
        <h1 id="title">Insert Products</h1>        
    </div>
</div>
<div class="row">
    <div class="col-lg-6 mx-auto">
        <?php echo form_open_multipart(base_url('admin/insert_products'),['name'=>'product_form','id'=>'product_form','class'=>'form']) ?>
        <div class="form-group">
            <?= form_label('Product Name','product_name',['class'=>'form-label'])?>
            <div class="input-group">
                <?=form_input(['name'=>'product_name','class'=>'form-control','auto-focus'=>'true','value'=>set_value('product_name')])?>
            </div>
            <?php echo form_error('product_name','<p class="text-danger">','</p>');?>
        </div>
        <div class="form-group">
            <?= form_label('Available Product Quantity','product_qty',['class'=>'form-label'])?>
            <div class="input-group">
                <?=form_input(['name'=>'product_qty','class'=>'form-control','auto-focus'=>'true','value'=>set_value('product_qty')])?>
            </div>
            <?php echo form_error('product_qty','<p class="text-danger">','</p>');?>
        </div>
        <div class="form-group">
            <?= form_label('Product Price ','product_price',['class'=>'form-label'])?>
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text">$</span>
              </div>
              <?=form_input(['name'=>'product_price','class'=>'form-control','auto-focus'=>'true','value'=>set_value('product_price')])?>      
              <div class="input-group-append">
                <span class="input-group-text">.00</span>
              </div>
            </div>
            <?php echo form_error('product_price','<p class="text-danger">','</p>');?>
        </div>
        <div class="form-group">
            <?= form_label('Product Image','product_image',['class'=>'form-label'])?>
            <div class="input-group mb-3">
                <div class="custom-file">
                    <?=form_upload(['name'=>'product_image','class'=>'custom-file-input form-control','id'=>'product_image'])?>
                    <?=form_label('Choose file','product_images',['class'=>'custom-file-label form-control'])?>
                    <!--input type="file" class="custom-file-input" id="inputGroupFile02">
                    <label class="custom-file-label" for="inputGroupFile02">Choose file</label-->
                  </div>                  
            </div>
            <?php echo form_error('product_image','<p class="text-danger">','</p>');?>
        </div>
        <div class="form-group">
            <div class="input-group">
                <?= form_submit(['value'=>'Submit','class'=>'btn btn-primary'])?>
                <?= form_reset(['value'=>'Reset','class'=>'btn btn-warning'])?>
            </div>
        </div>
        <?php echo form_close(); ?>
    </div>
</div>
<?php include('footer.php') ?>