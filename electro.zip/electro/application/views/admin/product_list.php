<?php     include('header.php');?>
<div class="col-lg-12 col-sm">
    <div class="row">
        <h1 id="title">
            Product list
        </h1>
    </div>
    <div class="row auto-mx">
        <table class="table">
            <?php if(is_array($products) && count($products)>0): ?>
                <th>
                    <td>ID</td>
                </th>
                <th>
                    <td>Product name</td>
                </th>
                <th>
                    <td>Price</td>
                </th>
                <?php foreach($products as $product): ?>
                    <tr>
                        <td><?php echo $product['id'] ?></td>
                    </tr>
                    <tr>
                        <td><?php echo $product['name'] ?></td>
                    </tr>
                    <tr>
                        <td><?php echo $product['price'] ?></td>
                    </tr>
                    <tr>
                        <td>
                            <button class="btn-primary">Edit</button>
                            <button class="btn-danger">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr colspan="3">
                    <td>No data available</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
</div>
<?php     include('footer.php');?>